package enums;

public enum TrainingStatus {
  Intake,
  Phase1,
  Phase2,
  Phase3,
  Phase4,
  Phase5,
  InService,
  Farm,
}
