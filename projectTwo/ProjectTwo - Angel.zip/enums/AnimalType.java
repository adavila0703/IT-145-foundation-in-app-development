package enums;

public enum AnimalType {
  Monkey,
  Dog,
}
