package enums;

public enum Gender {
  Female,
  Male,
}
