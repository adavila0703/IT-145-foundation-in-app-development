package enums;

public enum DogBreed {
  GermanShepherd,
  GreatDane,
  Chihuahua,
}
