package enums;

public enum MonkeyBreed {
  Capuchin,
  Guenon,
  Macaque,
  Marmoset,
}
